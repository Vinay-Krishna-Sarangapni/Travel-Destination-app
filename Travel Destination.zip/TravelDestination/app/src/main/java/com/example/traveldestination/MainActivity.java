package com.example.traveldestination;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {
    private DestinationListFragment listFragment;
    private SharedPreferences sharedPreferences;
    private boolean showOnlyVisited = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        sharedPreferences = getPreferences(MODE_PRIVATE);
        showOnlyVisited = sharedPreferences.getBoolean("showOnlyVisited", false);

        listFragment = new DestinationListFragment();
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.fragment_container, listFragment)
                .commit();

        findViewById(R.id.fab_add_destination).setOnClickListener(v -> showAddDestinationDialog());
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_reset_list) {
            resetList();
            return true;
        } else if (id == R.id.action_toggle_view) {
            toggleView();
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    private void showAddDestinationDialog() {
        AddDestinationFragment addFragment = new AddDestinationFragment();
        addFragment.show(getSupportFragmentManager(), "AddDestinationFragment");
    }

    private void resetList() {
        listFragment.resetList();
    }

    private void toggleView() {
        showOnlyVisited = !showOnlyVisited;
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean("showOnlyVisited", showOnlyVisited);
        editor.apply();
        listFragment.updateList(showOnlyVisited);
    }

    public DestinationListFragment getListFragment() {
        return listFragment;
    }

    public void setListFragment(DestinationListFragment listFragment) {
        this.listFragment = listFragment;
    }
}