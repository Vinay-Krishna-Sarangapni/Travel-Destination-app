package com.example.traveldestination;

public class Destination {
    private final String name;
    private boolean visited;

    public Destination(String name, boolean visited) {
        this.name = name;
        this.visited = visited;
    }

    public String getName() {
        return name;
    }

    public boolean isVisited() {
        return visited;
    }

    public void setVisited(boolean visited) {
        this.visited = visited;
    }
}
