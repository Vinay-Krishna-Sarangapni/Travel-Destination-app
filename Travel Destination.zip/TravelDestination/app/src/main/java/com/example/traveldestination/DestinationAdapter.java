package com.example.traveldestination;

import android.content.Context;
import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.TextView;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.List;

public class DestinationAdapter extends ArrayAdapter<Destination> {
    public DestinationAdapter(Context context, List<Destination> destinations) {
        super(context, 0, destinations);
    }

    @NonNull
    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        Destination destination = getItem(position);
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(android.R.layout.simple_list_item_1, parent, false);
        }
        TextView textView = convertView.findViewById(android.R.id.text1);
        textView.setText(destination.getName());
        textView.setTextColor(destination.isVisited() ? Color.GREEN : Color.BLACK);
        return convertView;
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults results = new FilterResults();
                List<Destination> filteredList = new ArrayList<>();

                if (constraint == null || constraint.length() == 0) {
                    filteredList.addAll(getOriginalList());
                } else {
                    for (Destination destination : getOriginalList()) {
                        if (constraint.equals("visited") && destination.isVisited()) {
                            filteredList.add(destination);
                        }
                    }
                }

                results.values = filteredList;
                results.count = filteredList.size();
                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                clear();
                addAll((List<Destination>) results.values);
                notifyDataSetChanged();
            }
        };
    }

    private List<Destination> getOriginalList() {
        List<Destination> originalList = new ArrayList<>();
        for (int i = 0; i < getCount(); i++) {
            originalList.add(getItem(i));
        }
        return originalList;
    }
}
