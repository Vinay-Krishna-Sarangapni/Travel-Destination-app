package com.example.traveldestination;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.fragment.app.DialogFragment;

public class AddDestinationFragment extends DialogFragment {
    private EditText editTextDestination;

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        LayoutInflater inflater = requireActivity().getLayoutInflater();
        View view = inflater.inflate(R.layout.fragment_add_destination, null);
        editTextDestination = view.findViewById(R.id.edit_text_destination);

        builder.setView(view)
                .setPositiveButton("Add", (dialog, id) -> {
                    String destinationName = editTextDestination.getText().toString();
                    if (!destinationName.isEmpty()) {
                        ((MainActivity) getActivity()).getListFragment().addDestination(destinationName);
                    }
                })
                .setNegativeButton("Cancel", (dialog, id) -> AddDestinationFragment.this.getDialog().cancel());
        return builder.create();
    }
}
