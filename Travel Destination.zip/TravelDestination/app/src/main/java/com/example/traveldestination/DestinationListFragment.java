package com.example.traveldestination;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.fragment.app.Fragment;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class DestinationListFragment extends Fragment {
    private ListView listView;
    private ArrayAdapter<Destination> adapter;
    private List<Destination> destinations;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_destination_list, container, false);
        listView = view.findViewById(R.id.list_view_destinations);
        destinations = loadDestinationsFromFile();
        adapter = new DestinationAdapter(getContext(), destinations);
        listView.setAdapter(adapter);

        listView.setOnItemLongClickListener((parent, view1, position, id) -> {
            Destination destination = destinations.get(position);
            destination.setVisited(!destination.isVisited());
            adapter.notifyDataSetChanged();
            saveDestinationsToFile();
            return true;
        });

        return view;
    }

    public void addDestination(String name) {
        destinations.add(new Destination(name, false));
        adapter.notifyDataSetChanged();
        saveDestinationsToFile();
    }

    public void resetList() {
        destinations.clear();
        adapter.notifyDataSetChanged();
        saveDestinationsToFile();
    }

    public void updateList(boolean showOnlyVisited) {
        adapter.getFilter().filter(showOnlyVisited ? "visited" : "");
    }

    private List<Destination> loadDestinationsFromFile() {
        List<Destination> loadedDestinations = new ArrayList<>();
        try {
            FileInputStream fis = getContext().openFileInput("destinations.txt");
            InputStreamReader isr = new InputStreamReader(fis);
            BufferedReader br = new BufferedReader(isr);
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(",");
                loadedDestinations.add(new Destination(parts[0], Boolean.parseBoolean(parts[1])));
            }
            br.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return loadedDestinations;
    }

    private void saveDestinationsToFile() {
        try {
            FileOutputStream fos = getContext().openFileOutput("destinations.txt", Context.MODE_PRIVATE);
            for (Destination destination : destinations) {
                String line = destination.getName() + "," + destination.isVisited() + "\n";
                fos.write(line.getBytes());
            }
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
